# Projet de base pour projet final B3 - Dev

HTTPS : `git clone https://github.com/paulintrognon-mds/final-exam.git`
ou
SSH : `git clone git@github.com:paulintrognon-mds/final-exam.git`

## Étape 1 : modifier cypress.json

Ouvrez cypress.json et remplacez https://guess-the-game.com par le lien du site que vous voulez tester.

## Étape 2 : Installez les dépendances

Installez les dépendances avec `npm install`

## Étape 3 : Lancez Cypress

Vous devrez à présent pouvoir lancer Cypress avec la commande `npm start`.

## Étape 4 : Écrivez vos tests !

Vous pouvez à présent écrire vos tests dans le dossier `cypress/integration/`.

Vous devez créer un fichier par suite de test Gherkin. Chacun de ces fichiers doit contenir un describe() qui correspond à la fonctionnalité, et un ou plusieurs it() pour chaque scénario de test. **Vos fichiers doivent terminer par .spec.js**.

Vous devrez donc à la fin avec 5 fichiers de tests, avec chacun un describe et un ou plusieurs it().

Une fois que vous avez terminez, envoyez-moi vos 5 fichiers .spec.js ainsi que vos tests Gherkin à l'email : mailto:paulin.trognon.ext@eduservices.org

Bon courage !

## Pour vous aider

- Cours sur Cypress : https://docs.google.com/presentation/d/1OQV8xhdUo77wJIKNKbDOerDPkMDBB_dvUb7kfk-6taE/edit#slide=id.g9b9a314f37_0_167
- Documentation : https://docs.cypress.io/guides/getting-started/writing-your-first-test.html#Write-your-first-test
- Exemples : https://docs.cypress.io/guides/references/assertions.html#Common-Assertions

N'hésitez pas à me contacter sur Teams si vous êtes bloqué.
