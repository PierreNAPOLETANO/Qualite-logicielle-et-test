describe('Access a repository', () => {
    // Je me rends à la page d'accueil de GitHub
    beforeEach(() => {
        cy.visit('/');
    });

    // Je vérifie que les éléments dont j'ai besoin existent
    // et je fait en sorte que j'arrive au repository du 1er projet
    // dans la liste des tendeance
    it('should find a repository', () => {
        cy.get('.body-fluid').should('exist');
        cy.get('.HeaderMenu-summary').contains('Explore');
        cy.get('.HeaderMenu-summary').contains('Explore').click();
        cy.get('.lh-condensed-ultra').contains('Trending');
        cy.get('.lh-condensed-ultra').contains('Trending').click();
        cy.get('article:first .h3 a').click();
    });
});