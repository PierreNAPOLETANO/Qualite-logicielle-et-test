describe('Makertplace page', () => {
    // Je me rends à la page d'accueil de github
    // Et je charge récupère les éléments commun aux 2 scenarios
    beforeEach(() => {
        cy.visit('/');
        cy.get('.body-fluid').should('exist');
        cy.get('.link-gray').contains('Help').should('exist');
        cy.get('.link-gray').contains('Help').click();
    });

    // Je vérifie que les éléments dont j'ai besoin existent
    // et je fais en sorte d'arrive à la doc de l'API Rest de Github
    it('should access to Github Rest API', () => {
        // cy.get('.body-fluid').should('exist');
        // cy.get('.link-gray').contains('Help').should('exist');
        // cy.get('.link-gray').contains('Help').click();
        cy.get('.btn-mktg').contains('REST API').should('exist');
        cy.get('.btn-mktg').contains('REST API').click();
        cy.get('.link-with-intro-title').contains('REST API overview').should('exist');
        cy.get('.link-with-intro-title').contains('REST API overview').click();
        cy.get('.article-link').contains('Resources in the REST API').should('exist');
        cy.get('.article-link').contains('Resources in the REST API').click();
    });

   // Je vérifie que les éléments dont j'ai besoin existent
    // et je fais en sorte d'arrive à la doc de l'API Rest de Github
    it('should access to Github GraphQL API', () => {
        // cy.get('.body-fluid').should('exist');
        // cy.get('.link-gray').contains('Help').should('exist');
        // cy.get('.link-gray').contains('Help').click();
        cy.get('.btn-mktg').contains('GraphQL API').should('exist');
        cy.get('.btn-mktg').contains('GraphQL API').click();
        cy.get('.link-with-intro-title').contains('Overview').should('exist');
        cy.get('.link-with-intro-title').contains('Overview').click();
        cy.get('.article-link').contains('About the GraphQL API').should('exist');
        cy.get('.article-link').contains('About the GraphQL API').click();
        cy.get('a').contains('Root endpoint').should('exist');
        cy.get('a').contains('Root endpoint').click();
    });
});