describe('Create an account', () => {
    // Je me rends à la page d'accueil de github
    beforeEach(() => {
        cy.visit('/');
    });

    // Je vérifie que les éléments dont j'ai besoin existes et
    // je suis redirigé vers la page de création de compte
    // même si je n'ai rien saisit dans le formulaire
    it('should create an account', () => {
        cy.get('.logged-out').should('exist');
        cy.get('.btn-mktg').contains('Sign up for GitHub');
        cy.get('.btn-mktg').contains('Sign up for GitHub').click();
    });    
});
