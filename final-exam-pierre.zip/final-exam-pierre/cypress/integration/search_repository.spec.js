describe('Homepage', () => {
    // Je me rends à la page d'accueil de github
    beforeEach(() => {
        cy.visit('/');
    });

    // Je vérifie que les éléments dont j'ai besoin existes
    // je suis redirigé vers une liste de projet contenant
    // le mot-clé Linux
    it('should find a repository', () => {
        cy.get('.body-fluid').should('exist');
        cy.get('.jump-to-field').should('exist');
        cy.get('.jump-to-field').type('Linux');
        cy.get('.jump-to-field').type('{enter}');
    });
});