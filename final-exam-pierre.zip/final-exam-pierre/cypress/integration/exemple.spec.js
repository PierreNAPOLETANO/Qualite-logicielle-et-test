describe('Homepage', () => {
  it('should open the homepage', () => {
    cy.visit('/');
  });
});
