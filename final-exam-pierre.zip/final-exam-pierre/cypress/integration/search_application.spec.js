describe('Makertplace page', () => {
    // Je me rends à la page de la markeplace de GitHub
    beforeEach(() => {
        cy.visit('/marketplace');
    });

    // Je vérifie que les éléments dont j'ai besoin existes
    // je suis redirigé vers le projet que je cherchais
    // en l'occurence 'GitHub Learning Lab'
    it('should find a repository', () => {
        cy.get('.logged-out').should('exist');
        cy.get('input[name="query"]').should('exist');
        cy.get('input[name="query"]').type('GitHub Learning Lab');
        cy.get('input[name="query"]').type('{enter}');
    });
});